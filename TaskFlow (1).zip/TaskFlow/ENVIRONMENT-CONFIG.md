# TaskFlow - Environment Configuration Guide

This guide covers all environment variables, configuration options, and deployment settings for TaskFlow.

## Table of Contents
- [Environment Variables](#environment-variables)
- [Database Configuration](#database-configuration)
- [Production Configuration](#production-configuration)
- [SSL Configuration](#ssl-configuration)
- [Performance Tuning](#performance-tuning)
- [Security Configuration](#security-configuration)
- [Monitoring and Logging](#monitoring-and-logging)

---

## Environment Variables

### Required Variables

| Variable | Description | Example | Required |
|----------|-------------|---------|----------|
| `NODE_ENV` | Application environment | `production` | Yes |
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@localhost:5432/taskflow` | Yes |
| `PORT` | Application port | `3000` | No (defaults to 3000) |

### Database Variables

| Variable | Description | Example | Required |
|----------|-------------|---------|----------|
| `PGHOST` | Database host | `localhost` | No |
| `PGPORT` | Database port | `5432` | No |
| `PGUSER` | Database username | `taskflow_user` | No |
| `PGPASSWORD` | Database password | `secure_password` | No |
| `PGDATABASE` | Database name | `taskflow` | No |

### Optional Variables

| Variable | Description | Example | Default |
|----------|-------------|---------|---------|
| `LOG_LEVEL` | Logging level | `info` | `info` |
| `CORS_ORIGIN` | CORS allowed origins | `https://yourdomain.com` | `*` |
| `SESSION_SECRET` | Session encryption key | `your-secret-key` | Generated |
| `RATE_LIMIT_WINDOW` | Rate limit window (ms) | `900000` | 15 minutes |
| `RATE_LIMIT_MAX` | Max requests per window | `100` | 100 |

### Environment File Examples

#### Development (.env.development)
```env
NODE_ENV=development
DATABASE_URL=postgresql://taskflow:password@localhost:5432/taskflow_dev
PORT=3000
LOG_LEVEL=debug
CORS_ORIGIN=http://localhost:5173
PGHOST=localhost
PGPORT=5432
PGUSER=taskflow
PGPASSWORD=password
PGDATABASE=taskflow_dev
```

#### Production (.env.production)
```env
NODE_ENV=production
DATABASE_URL=postgresql://taskflow_user:secure_password@localhost:5432/taskflow
PORT=3000
LOG_LEVEL=info
CORS_ORIGIN=https://yourdomain.com
SESSION_SECRET=your-super-secure-session-secret-key-here
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
PGHOST=localhost
PGPORT=5432
PGUSER=taskflow_user
PGPASSWORD=secure_password
PGDATABASE=taskflow
```

#### Docker (.env.docker)
```env
NODE_ENV=production
DATABASE_URL=postgresql://taskflow:password@db:5432/taskflow
PORT=3000
LOG_LEVEL=info
CORS_ORIGIN=https://yourdomain.com
PGHOST=db
PGPORT=5432
PGUSER=taskflow
PGPASSWORD=password
PGDATABASE=taskflow
```

---

## Database Configuration

### PostgreSQL Setup

#### Basic Configuration
```sql
-- Create database
CREATE DATABASE taskflow;

-- Create user
CREATE USER taskflow_user WITH PASSWORD 'your_secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE taskflow TO taskflow_user;
ALTER USER taskflow_user CREATEDB;

-- Connection limit (optional)
ALTER USER taskflow_user CONNECTION LIMIT 20;
```

#### Performance Tuning
```sql
-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Optimize for application
ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';
ALTER SYSTEM SET max_connections = 100;
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET work_mem = '4MB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
```

#### Connection Pool Configuration
```javascript
// In your application (server/db.ts)
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20, // Maximum connections
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
  // SSL configuration for production
  ssl: process.env.NODE_ENV === 'production' ? {
    rejectUnauthorized: false
  } : false
});
```

### Database Backup Configuration

#### Automated Backup Script
```bash
#!/bin/bash
# /opt/taskflow-db-backup.sh

# Configuration
DB_NAME="taskflow"
DB_USER="taskflow_user"
BACKUP_DIR="/opt/backups/database"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7

# Create backup directory
mkdir -p $BACKUP_DIR

# Perform backup
pg_dump -h localhost -U $DB_USER -d $DB_NAME -f $BACKUP_DIR/taskflow_$DATE.sql

# Compress backup
gzip $BACKUP_DIR/taskflow_$DATE.sql

# Remove old backups
find $BACKUP_DIR -name "taskflow_*.sql.gz" -mtime +$RETENTION_DAYS -delete

# Log backup
echo "$(date): Database backup completed - taskflow_$DATE.sql.gz" >> /var/log/taskflow-backup.log
```

#### Schedule with Cron
```bash
# Add to crontab
0 2 * * * /opt/taskflow-db-backup.sh
```

---

## Production Configuration

### PM2 Ecosystem Configuration

Create `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'taskflow',
    script: 'dist/index.js',
    instances: 'max', // Use all CPU cores
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development',
      PORT: 3000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
      LOG_LEVEL: 'info'
    },
    // Logging
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    
    // Process management
    max_memory_restart: '1G',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s',
    
    // Health monitoring
    health_check_grace_period: 3000,
    
    // Auto restart on file changes (development only)
    watch: process.env.NODE_ENV === 'development',
    ignore_watch: ['node_modules', 'logs', 'dist'],
    
    // Log rotation
    log_date_format: 'YYYY-MM-DD HH:mm Z',
    merge_logs: true,
    
    // Environment specific settings
    source_map_support: true,
    instance_var: 'INSTANCE_ID'
  }],
  
  // Deployment configuration
  deploy: {
    production: {
      user: 'deploy',
      host: 'your-server.com',
      ref: 'origin/main',
      repo: 'git@github.com:your-username/taskflow.git',
      path: '/var/www/taskflow',
      'pre-deploy-local': '',
      'post-deploy': 'npm install && npm run build && pm2 reload ecosystem.config.js --env production',
      'pre-setup': ''
    }
  }
};
```

### Systemd Service (Alternative to PM2)

Create `/etc/systemd/system/taskflow.service`:
```ini
[Unit]
Description=TaskFlow Node.js Application
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=taskflow
WorkingDirectory=/opt/taskflow
ExecStart=/usr/bin/node dist/index.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=taskflow
Environment=NODE_ENV=production
Environment=PORT=3000
EnvironmentFile=/opt/taskflow/.env

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/taskflow/logs

# Resource limits
LimitNOFILE=65536
MemoryLimit=1G

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable taskflow
sudo systemctl start taskflow
sudo systemctl status taskflow
```

---

## SSL Configuration

### Let's Encrypt with Certbot

#### Installation
```bash
# Ubuntu/Debian
sudo apt install certbot python3-certbot-nginx

# CentOS/RHEL
sudo yum install certbot python3-certbot-nginx
```

#### Certificate Generation
```bash
# Get certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Test renewal
sudo certbot renew --dry-run

# Auto-renewal
echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -
```

### Custom SSL Configuration

#### Generate Self-Signed Certificate (Development)
```bash
# Create SSL directory
sudo mkdir -p /etc/ssl/taskflow

# Generate private key
sudo openssl genrsa -out /etc/ssl/taskflow/private.key 2048

# Generate certificate
sudo openssl req -new -x509 -key /etc/ssl/taskflow/private.key -out /etc/ssl/taskflow/certificate.crt -days 365
```

#### Application SSL Configuration
```javascript
// In server/index.ts for HTTPS
import https from 'https';
import fs from 'fs';

if (process.env.NODE_ENV === 'production') {
  const options = {
    key: fs.readFileSync('/etc/ssl/taskflow/private.key'),
    cert: fs.readFileSync('/etc/ssl/taskflow/certificate.crt')
  };
  
  const httpsServer = https.createServer(options, app);
  httpsServer.listen(443, () => {
    console.log('HTTPS Server running on port 443');
  });
}
```

---

## Performance Tuning

### Node.js Optimization

#### Memory Management
```bash
# Set Node.js memory limits
export NODE_OPTIONS="--max-old-space-size=1024"

# Garbage collection optimization
export NODE_OPTIONS="--max-old-space-size=1024 --optimize-for-size"
```

#### Cluster Configuration
```javascript
// In server/cluster.js
import cluster from 'cluster';
import os from 'os';

if (cluster.isPrimary) {
  const numCPUs = os.cpus().length;
  
  console.log(`Master ${process.pid} is running`);
  
  // Fork workers
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
  
  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} died`);
    cluster.fork();
  });
} else {
  // Workers can share any TCP port
  import('./index.js');
  console.log(`Worker ${process.pid} started`);
}
```

### Database Optimization

#### Connection Pool Tuning
```javascript
// Optimal pool configuration
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20, // Maximum connections
  min: 5,  // Minimum connections
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
  acquireTimeoutMillis: 60000,
  createTimeoutMillis: 30000,
  destroyTimeoutMillis: 5000,
  reapIntervalMillis: 1000,
  createRetryIntervalMillis: 200,
  propagateCreateError: false
});
```

#### Query Optimization
```sql
-- Add indexes for better performance
CREATE INDEX CONCURRENTLY idx_tasks_completed ON tasks(completed);
CREATE INDEX CONCURRENTLY idx_tasks_created_at ON tasks(created_at DESC);
CREATE INDEX CONCURRENTLY idx_tasks_updated_at ON tasks(updated_at DESC);

-- Analyze query performance
ANALYZE tasks;

-- Monitor slow queries
SELECT query, mean_exec_time, calls 
FROM pg_stat_statements 
ORDER BY mean_exec_time DESC 
LIMIT 10;
```

---

## Security Configuration

### Application Security

#### Rate Limiting
```javascript
// In server/index.ts
import rateLimit from 'express-rate-limit';

// General rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP',
  standardHeaders: true,
  legacyHeaders: false,
});

// API specific rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  keyGenerator: (req) => {
    return req.ip;
  },
});

app.use('/api/', apiLimiter);
app.use(limiter);
```

#### Security Headers
```javascript
import helmet from 'helmet';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      fontSrc: ["'self'", "data:"],
      connectSrc: ["'self'"]
    }
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));
```

### Database Security

#### Connection Security
```bash
# PostgreSQL configuration (/etc/postgresql/13/main/postgresql.conf)
ssl = on
ssl_cert_file = '/etc/ssl/certs/server.crt'
ssl_key_file = '/etc/ssl/private/server.key'
ssl_ciphers = 'HIGH:MEDIUM:+3DES:!aNULL'
ssl_prefer_server_ciphers = on

# Connection authentication (/etc/postgresql/13/main/pg_hba.conf)
hostssl all all 0.0.0.0/0 md5
```

### Server Security

#### Firewall Configuration
```bash
# UFW (Ubuntu)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Fail2ban for SSH protection
sudo apt install fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

---

## Monitoring and Logging

### Application Logging

#### Winston Logger Configuration
```javascript
// logger.js
import winston from 'winston';

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'taskflow' },
  transports: [
    new winston.transports.File({ 
      filename: 'logs/error.log', 
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    new winston.transports.File({ 
      filename: 'logs/combined.log',
      maxsize: 5242880,
      maxFiles: 5,
    })
  ],
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}
```

### Health Monitoring

#### Health Check Endpoint
```javascript
// In server/routes.ts
app.get('/health', (req, res) => {
  const healthcheck = {
    uptime: process.uptime(),
    message: 'OK',
    timestamp: Date.now(),
    environment: process.env.NODE_ENV,
    version: process.env.npm_package_version,
    memory: process.memoryUsage(),
    database: 'connected' // Add actual DB health check
  };
  
  try {
    res.status(200).send(healthcheck);
  } catch (error) {
    healthcheck.message = error;
    res.status(503).send();
  }
});
```

### Log Rotation

#### Logrotate Configuration
```bash
# /etc/logrotate.d/taskflow
/opt/taskflow/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    copytruncate
    postrotate
        systemctl reload taskflow
    endscript
}
```

### Monitoring Tools

#### PM2 Monitoring
```bash
# Install PM2 monitoring
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:compress true
pm2 set pm2-logrotate:retain 7

# Enable web monitoring
pm2 web
```

#### System Monitoring Script
```bash
#!/bin/bash
# /opt/taskflow-monitor.sh

# Check application status
APP_STATUS=$(pm2 jlist | jq -r '.[0].pm2_env.status')

# Check database connection
DB_STATUS=$(pg_isready -h localhost -p 5432 -U taskflow_user)

# Check disk space
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')

# Check memory usage
MEMORY_USAGE=$(free | awk 'NR==2{printf "%.2f%%", $3*100/$2}')

# Log status
echo "$(date): App: $APP_STATUS, DB: $DB_STATUS, Disk: $DISK_USAGE%, Memory: $MEMORY_USAGE" >> /var/log/taskflow-monitor.log

# Alert if issues
if [ "$APP_STATUS" != "online" ] || [ "$DISK_USAGE" -gt 80 ]; then
    # Send alert (email, webhook, etc.)
    echo "Alert: TaskFlow monitoring detected issues" | mail -s "TaskFlow Alert" admin@yourdomain.com
fi
```

---

## Configuration Validation

### Environment Validation Script
```javascript
// validate-env.js
const requiredEnvVars = [
  'NODE_ENV',
  'DATABASE_URL',
  'PORT'
];

const optionalEnvVars = [
  'LOG_LEVEL',
  'CORS_ORIGIN',
  'SESSION_SECRET'
];

function validateEnvironment() {
  const missing = requiredEnvVars.filter(envVar => !process.env[envVar]);
  
  if (missing.length > 0) {
    console.error('Missing required environment variables:', missing);
    process.exit(1);
  }
  
  console.log('Environment validation passed');
  
  // Log configured variables (without sensitive data)
  console.log('Configured environment:');
  console.log(`NODE_ENV: ${process.env.NODE_ENV}`);
  console.log(`PORT: ${process.env.PORT}`);
  console.log(`LOG_LEVEL: ${process.env.LOG_LEVEL || 'info'}`);
  console.log(`DATABASE: ${process.env.DATABASE_URL ? 'configured' : 'not configured'}`);
}

validateEnvironment();
```

Run validation:
```bash
node validate-env.js
```

This comprehensive configuration guide should help you properly set up TaskFlow in any environment. Adjust the settings based on your specific requirements and infrastructure.