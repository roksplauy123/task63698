import { useState } from "react";
import { CheckCircle, Cloud, User } from "lucide-react";
import { TaskForm } from "@/components/task-form";
import { TaskList } from "@/components/task-list";
import { TaskStats } from "@/components/task-stats";
import { TaskFilters } from "@/components/task-filters";
import { Button } from "@/components/ui/button";
import { useTasks } from "@/hooks/use-tasks";

type FilterType = 'all' | 'active' | 'completed';

export default function Home() {
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const { data: tasks = [], isLoading } = useTasks();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b border-border sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-foreground">TaskFlow</h1>
              <span className="text-xs bg-secondary/20 text-secondary px-2 py-1 rounded-full font-medium">Beta</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-green-600 text-sm">
                <Cloud className="h-4 w-4" />
                <span>Synced</span>
              </div>
              <Button size="sm" variant="ghost" className="w-8 h-8 p-0 bg-primary text-white rounded-full hover:bg-primary/90">
                <User className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {/* Stats Overview */}
        <TaskStats tasks={tasks} isLoading={isLoading} />

        {/* Task Creation Form */}
        <TaskForm />

        {/* Filter Tabs */}
        <TaskFilters 
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
        />

        {/* Task List */}
        <TaskList 
          tasks={tasks} 
          isLoading={isLoading}
          filter={activeFilter}
        />

        {/* Load More Section */}
        {tasks.length > 0 && !isLoading && (
          <div className="text-center mt-8">
            <Button 
              variant="outline"
              className="px-6 py-3 border border-border text-foreground rounded hover:bg-card transition-colors font-medium"
            >
              Load More Tasks
            </Button>
          </div>
        )}
      </main>

      {/* Floating Action Button (Mobile) */}
      <Button className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg hover:bg-primary/90 transition-all duration-200 hover:scale-105 md:hidden">
        <CheckCircle className="h-6 w-6" />
      </Button>
    </div>
  );
}
