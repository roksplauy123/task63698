import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Clock, List } from "lucide-react";
import type { Task } from "@shared/schema";

interface TaskStatsProps {
  tasks: Task[];
  isLoading?: boolean;
}

export function TaskStats({ tasks, isLoading }: TaskStatsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="h-4 bg-muted rounded w-16 mb-2"></div>
                  <div className="h-8 bg-muted rounded w-8"></div>
                </div>
                <div className="w-10 h-10 bg-muted rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const total = tasks.length;
  const completed = tasks.filter(task => task.completed).length;
  const pending = total - completed;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
      <Card className="shadow-sm border border-border hover-lift">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total Tasks</p>
              <p className="text-2xl font-bold text-foreground">{total}</p>
            </div>
            <div className="w-10 h-10 bg-primary/10 rounded flex items-center justify-center">
              <List className="h-5 w-5 text-primary" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-sm border border-border hover-lift">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Completed</p>
              <p className="text-2xl font-bold text-green-600">{completed}</p>
            </div>
            <div className="w-10 h-10 bg-green-50 rounded flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-sm border border-border hover-lift">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Pending</p>
              <p className="text-2xl font-bold text-primary">{pending}</p>
            </div>
            <div className="w-10 h-10 bg-secondary/10 rounded flex items-center justify-center">
              <Clock className="h-5 w-5 text-secondary" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
