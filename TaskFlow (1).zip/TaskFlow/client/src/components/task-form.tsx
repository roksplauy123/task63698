import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Plus } from "lucide-react";
import { useCreateTask } from "@/hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";

export function TaskForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const { toast } = useToast();
  
  const createTask = useCreateTask();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "Task title is required",
        variant: "destructive",
      });
      return;
    }

    try {
      await createTask.mutateAsync({
        title: title.trim(),
        description: description.trim(),
      });
      
      setTitle("");
      setDescription("");
      
      toast({
        title: "Success",
        description: "Task created successfully!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="shadow-sm border border-border mb-6 hover-lift">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-start space-x-4">
            <div className="flex-1">
              <Input
                type="text"
                placeholder="What needs to be done?"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="px-4 py-3 border border-border rounded focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
                disabled={createTask.isPending}
              />
            </div>
            <Button
              type="submit"
              disabled={createTask.isPending || !title.trim()}
              className="px-6 py-3 bg-primary text-white rounded hover:bg-primary/90 focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-all duration-200 font-medium"
            >
              {createTask.isPending ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              ) : (
                <Plus className="h-4 w-4 mr-2" />
              )}
              Add Task
            </Button>
          </div>
          <div className="flex-1">
            <Textarea
              placeholder="Add a description (optional)"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 border border-border rounded focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 resize-none"
              disabled={createTask.isPending}
            />
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
