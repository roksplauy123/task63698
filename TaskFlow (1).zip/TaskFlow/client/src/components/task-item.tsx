import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Edit2, Trash2, Save, X, Clock } from "lucide-react";
import { useUpdateTask, useDeleteTask } from "@/hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";
import type { Task } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface TaskItemProps {
  task: Task;
}

export function TaskItem({ task }: TaskItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(task.title);
  const [editDescription, setEditDescription] = useState(task.description || "");
  
  const { toast } = useToast();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();

  const handleToggleComplete = async () => {
    try {
      await updateTask.mutateAsync({
        id: task.id,
        task: { completed: !task.completed },
      });
      
      toast({
        title: task.completed ? "Task marked as incomplete" : "Task completed!",
        description: task.completed ? undefined : "Great job! 🎉",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const handleSaveEdit = async () => {
    if (!editTitle.trim()) {
      toast({
        title: "Error",
        description: "Task title cannot be empty",
        variant: "destructive",
      });
      return;
    }

    try {
      await updateTask.mutateAsync({
        id: task.id,
        task: {
          title: editTitle.trim(),
          description: editDescription.trim(),
        },
      });
      
      setIsEditing(false);
      
      toast({
        title: "Success",
        description: "Task updated successfully!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditTitle(task.title);
    setEditDescription(task.description || "");
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this task? This action cannot be undone.")) {
      return;
    }

    try {
      await deleteTask.mutateAsync(task.id);
      
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    }
  };

  const isLoading = updateTask.isPending || deleteTask.isPending;

  return (
    <Card className={`shadow-sm border border-border hover-lift slide-in transition-all duration-200 ${
      task.completed ? 'task-completed' : ''
    } ${isEditing ? 'border-primary border-2' : ''}`}>
      <CardContent className="p-4">
        {isEditing ? (
          <div className="space-y-3">
            <div className="flex items-start space-x-4">
              <button
                onClick={handleToggleComplete}
                disabled={isLoading}
                className={`mt-1 w-5 h-5 border-2 rounded-full task-checkbox transition-all duration-200 flex items-center justify-center ${
                  task.completed
                    ? 'bg-green-600 border-green-600'
                    : 'border-muted-foreground hover:border-primary'
                }`}
              >
                {task.completed && <Check className="h-3 w-3 text-white" />}
              </button>
              <div className="flex-1 space-y-2">
                <Input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded focus:ring-2 focus:ring-primary focus:border-transparent"
                  disabled={isLoading}
                />
                <Textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-border rounded focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  placeholder="Add a description (optional)"
                  disabled={isLoading}
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>{formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}</span>
                <span className="flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  Editing
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  onClick={handleSaveEdit}
                  disabled={isLoading || !editTitle.trim()}
                  className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-600/90 transition-colors"
                >
                  {isLoading ? (
                    <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Save className="h-3 w-3" />
                  )}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleCancelEdit}
                  disabled={isLoading}
                  className="px-3 py-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-start space-x-4">
            <button
              onClick={handleToggleComplete}
              disabled={isLoading}
              className={`mt-1 w-5 h-5 border-2 rounded-full task-checkbox transition-all duration-200 flex items-center justify-center ${
                task.completed
                  ? 'bg-green-600 border-green-600'
                  : 'border-muted-foreground hover:border-primary'
              }`}
            >
              {isLoading ? (
                <div className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin" />
              ) : (
                task.completed && <Check className="h-3 w-3 text-white" />
              )}
            </button>
            
            <div className="flex-1 min-w-0">
              <h3 className={`font-medium mb-1 task-title ${task.completed ? 'line-through opacity-60' : ''}`}>
                {task.title}
              </h3>
              {task.description && (
                <p className={`text-sm mb-2 text-muted-foreground ${task.completed ? 'opacity-60' : ''}`}>
                  {task.description}
                </p>
              )}
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>{formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}</span>
                {task.completed && (
                  <span className="flex items-center text-green-600">
                    <Check className="h-3 w-3 mr-1" />
                    Completed
                  </span>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsEditing(true)}
                disabled={isLoading}
                className="p-2 text-muted-foreground hover:text-primary transition-colors"
              >
                <Edit2 className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleDelete}
                disabled={isLoading}
                className="p-2 text-muted-foreground hover:text-destructive transition-colors"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
