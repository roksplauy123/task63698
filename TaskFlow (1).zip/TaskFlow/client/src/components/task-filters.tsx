import { Button } from "@/components/ui/button";
import { MoreHorizontal, SortAsc } from "lucide-react";

type FilterType = 'all' | 'active' | 'completed';

interface TaskFiltersProps {
  activeFilter: FilterType;
  onFilterChange: (filter: FilterType) => void;
}

export function TaskFilters({ activeFilter, onFilterChange }: TaskFiltersProps) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex space-x-1 bg-card p-1 rounded border border-border">
        <Button
          variant={activeFilter === 'all' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onFilterChange('all')}
          className="text-sm font-medium"
        >
          All Tasks
        </Button>
        <Button
          variant={activeFilter === 'active' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onFilterChange('active')}
          className="text-sm font-medium"
        >
          Active
        </Button>
        <Button
          variant={activeFilter === 'completed' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onFilterChange('completed')}
          className="text-sm font-medium"
        >
          Completed
        </Button>
      </div>
      
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
          <SortAsc className="h-4 w-4 mr-2" />
          Sort
        </Button>
        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
