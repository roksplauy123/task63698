import { TaskItem } from "./task-item";
import { CheckCircle } from "lucide-react";
import type { Task } from "@shared/schema";

interface TaskListProps {
  tasks: Task[];
  isLoading?: boolean;
  filter: 'all' | 'active' | 'completed';
}

export function TaskList({ tasks, isLoading, filter }: TaskListProps) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-card p-4 rounded border border-border shadow-sm animate-pulse">
            <div className="flex items-start space-x-4">
              <div className="w-5 h-5 bg-muted rounded-full mt-1"></div>
              <div className="flex-1">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/4"></div>
              </div>
              <div className="flex space-x-2">
                <div className="w-8 h-8 bg-muted rounded"></div>
                <div className="w-8 h-8 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Filter tasks based on current filter
  const filteredTasks = tasks.filter(task => {
    switch (filter) {
      case 'active':
        return !task.completed;
      case 'completed':
        return task.completed;
      default:
        return true;
    }
  });

  if (filteredTasks.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="h-8 w-8 text-primary" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">
          {filter === 'completed' ? 'No completed tasks' : 
           filter === 'active' ? 'No active tasks' : 'No tasks yet'}
        </h3>
        <p className="text-muted-foreground mb-6">
          {filter === 'completed' ? 'Complete some tasks to see them here' :
           filter === 'active' ? 'All tasks are completed! Great job!' :
           'Create your first task to get started with TaskFlow'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {filteredTasks.map((task) => (
        <TaskItem key={task.id} task={task} />
      ))}
    </div>
  );
}
