# TaskFlow - Installation Guide

## Prerequisites

Before installing TaskFlow, ensure you have:

- Ubuntu/Debian server (18.04+ recommended) or CentOS/RHEL 7+
- Root or sudo access
- Domain name pointing to your server
- At least 1GB RAM and 10GB disk space

## Installation Methods

Choose one of the following installation methods:

1. [Manual Installation with Nginx](#manual-installation-with-nginx)
2. [Installation with Control Panels](#installation-with-control-panels)
3. [aaPanel Deployment](#aapanel-deployment)
4. [Docker Installation](#docker-installation)

---

## Manual Installation with Nginx

### Step 1: Update System

```bash
# Ubuntu/Debian
sudo apt update && sudo apt upgrade -y

# CentOS/RHEL
sudo yum update -y
```

### Step 2: Install Required Dependencies

```bash
# Ubuntu/Debian
sudo apt install -y curl wget git nginx postgresql postgresql-contrib

# CentOS/RHEL
sudo yum install -y curl wget git nginx postgresql postgresql-server postgresql-contrib
sudo postgresql-setup initdb
sudo systemctl enable postgresql
```

### Step 3: Install Node.js

```bash
# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 4: Setup PostgreSQL Database

```bash
# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE taskflow;"
sudo -u postgres psql -c "CREATE USER taskflow_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE taskflow TO taskflow_user;"
sudo -u postgres psql -c "ALTER USER taskflow_user CREATEDB;"
```

### Step 5: Clone and Setup Application

```bash
# Clone the repository
git clone https://github.com/your-username/taskflow.git
cd taskflow

# Install dependencies
npm install

# Create environment file
cp .env.example .env
```

### Step 6: Configure Environment Variables

Edit the `.env` file:

```bash
nano .env
```

Add the following configuration:

```env
NODE_ENV=production
DATABASE_URL=postgresql://taskflow_user:your_secure_password@localhost:5432/taskflow
PORT=3000
PGHOST=localhost
PGPORT=5432
PGUSER=taskflow_user
PGPASSWORD=your_secure_password
PGDATABASE=taskflow
```

### Step 7: Build and Deploy Database

```bash
# Push database schema
npm run db:push

# Build the application
npm run build
```

### Step 8: Setup PM2 Process Manager

```bash
# Install PM2 globally
sudo npm install -g pm2

# Create PM2 ecosystem file
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'taskflow',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
EOF

# Create logs directory
mkdir -p logs

# Start the application
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

### Step 9: Configure Nginx

Create Nginx configuration:

```bash
sudo nano /etc/nginx/sites-available/taskflow
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/javascript application/xml+rss application/json;

    # Main location block
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # API routes
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site and restart Nginx:

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/taskflow /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Step 10: Setup SSL with Let's Encrypt

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal
sudo crontab -e
# Add this line:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## Installation with Control Panels

### cPanel/WHM Installation

1. **Upload Files**
   - Create a new subdomain or addon domain
   - Upload the built application to the domain's public_html folder
   - Extract the files

2. **Database Setup**
   - Go to MySQL Databases in cPanel
   - Create database: `username_taskflow`
   - Create user: `username_taskflow_user`
   - Assign user to database with all privileges

3. **Node.js App Setup**
   - Go to Node.js Selector in cPanel
   - Create new Node.js application
   - Set Node.js version to 20.x
   - Set application root to your domain folder
   - Set startup file to `dist/index.js`

4. **Environment Variables**
   - In Node.js app settings, add environment variables:
     ```
     NODE_ENV=production
     DATABASE_URL=postgresql://username_taskflow_user:password@localhost:5432/username_taskflow
     PORT=3000
     ```

### Plesk Panel Installation

1. **Create Domain**
   - Add new domain in Plesk
   - Enable Node.js support

2. **Upload Application**
   - Use File Manager to upload application files
   - Extract to httpdocs folder

3. **Database Configuration**
   - Go to Databases
   - Create PostgreSQL database
   - Note connection details

4. **Node.js Configuration**
   - Go to Node.js settings
   - Set Node.js version to 20.x
   - Set document root
   - Add environment variables
   - Set startup script to `dist/index.js`

### DirectAdmin Installation

1. **Domain Setup**
   - Create subdomain or addon domain
   - Enable Node.js if available

2. **File Upload**
   - Upload application via File Manager
   - Extract to public_html

3. **Database Setup**
   - Create PostgreSQL database
   - Create database user
   - Note connection credentials

4. **Application Configuration**
   - Configure Node.js application
   - Set environment variables
   - Start the application

---

## aaPanel Deployment

aaPanel is a popular web hosting control panel that provides an intuitive interface for server management. For detailed aaPanel deployment instructions, see the dedicated guide:

**[📖 Complete aaPanel Deployment Guide](AAPANEL-DEPLOYMENT.md)**

### Quick aaPanel Setup Overview:

1. **Install aaPanel**
   ```bash
   wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh
   sudo bash install.sh aapanel
   ```

2. **Install Required Components**
   - Nginx (Latest version)
   - PostgreSQL (Version 13+)
   - Node.js (Version 18+)
   - PM2 (Process manager)

3. **Create Website and Database**
   - Add domain in aaPanel
   - Create PostgreSQL database and user
   - Configure reverse proxy to Node.js app

4. **Deploy Application**
   - Upload TaskFlow files via File Manager
   - Install dependencies: `npm install --production`
   - Configure environment variables
   - Start with PM2: `pm2 start ecosystem.config.js`

5. **Configure SSL**
   - Enable Let's Encrypt SSL via aaPanel
   - Force HTTPS redirect

**Key Benefits of aaPanel:**
- Web-based control panel interface
- One-click SSL certificates with Let's Encrypt
- Built-in monitoring and backup tools
- Easy database management
- Nginx reverse proxy configuration
- Automated security updates

For complete step-by-step instructions, troubleshooting, and optimization tips, refer to the [aaPanel Deployment Guide](AAPANEL-DEPLOYMENT.md).

---

## Docker Installation

### Step 1: Install Docker

```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### Step 2: Create Docker Configuration

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    container_name: taskflow-app
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://taskflow:password@db:5432/taskflow
    depends_on:
      - db
    volumes:
      - ./logs:/app/logs

  db:
    image: postgres:15-alpine
    container_name: taskflow-db
    restart: unless-stopped
    environment:
      - POSTGRES_DB=taskflow
      - POSTGRES_USER=taskflow
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  nginx:
    image: nginx:alpine
    container_name: taskflow-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - app

volumes:
  postgres_data:
```

Create `Dockerfile`:

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application files
COPY . .

# Build the application
RUN npm run build

# Create logs directory
RUN mkdir -p logs

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3000/api/health || exit 1

# Start the application
CMD ["node", "dist/index.js"]
```

### Step 3: Deploy with Docker

```bash
# Clone repository
git clone https://github.com/your-username/taskflow.git
cd taskflow

# Create environment file
cp .env.example .env
# Edit .env with your configuration

# Build and start containers
docker-compose up -d

# View logs
docker-compose logs -f
```

---

## Post-Installation

### Security Configuration

1. **Firewall Setup**
```bash
# Ubuntu/Debian with UFW
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# CentOS/RHEL with firewalld
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload
```

2. **Database Security**
```bash
# Secure PostgreSQL installation
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'strong_password';"

# Configure pg_hba.conf for security
sudo nano /etc/postgresql/*/main/pg_hba.conf
```

3. **Application Security**
   - Change default passwords
   - Enable HTTPS only
   - Configure CSP headers
   - Set up monitoring

### Monitoring Setup

1. **Application Monitoring**
```bash
# Install PM2 monitoring
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:compress true
pm2 set pm2-logrotate:retain 7
```

2. **System Monitoring**
   - Set up log rotation
   - Configure monitoring alerts
   - Enable automatic backups

### Backup Configuration

1. **Database Backup**
```bash
# Create backup script
cat > /opt/taskflow-backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

# Database backup
pg_dump -h localhost -U taskflow_user taskflow > $BACKUP_DIR/taskflow_db_$DATE.sql

# Application backup
tar -czf $BACKUP_DIR/taskflow_app_$DATE.tar.gz /path/to/taskflow

# Keep only last 7 days of backups
find $BACKUP_DIR -name "taskflow_*" -mtime +7 -delete
EOF

chmod +x /opt/taskflow-backup.sh
```

2. **Cron Job for Backups**
```bash
# Add to crontab
echo "0 2 * * * /opt/taskflow-backup.sh" | crontab -
```

---

## Troubleshooting

### Common Issues

1. **Application Won't Start**
   - Check logs: `pm2 logs taskflow`
   - Verify database connection
   - Check environment variables

2. **Database Connection Issues**
   - Verify PostgreSQL is running: `sudo systemctl status postgresql`
   - Check database credentials
   - Test connection: `psql -h localhost -U taskflow_user -d taskflow`

3. **Nginx Configuration Issues**
   - Test configuration: `sudo nginx -t`
   - Check logs: `sudo tail -f /var/log/nginx/error.log`
   - Verify proxy settings

4. **SSL Certificate Issues**
   - Renew certificate: `sudo certbot renew`
   - Check certificate status: `sudo certbot certificates`

### Performance Optimization

1. **Database Optimization**
   - Add database indexes
   - Configure connection pooling
   - Optimize queries

2. **Application Optimization**
   - Enable gzip compression
   - Configure caching
   - Optimize static file serving

3. **Server Optimization**
   - Configure swap if needed
   - Optimize Nginx settings
   - Set up CDN for static assets

---

## Maintenance

### Regular Tasks

1. **Weekly**
   - Check application logs
   - Monitor disk space
   - Review security logs

2. **Monthly**
   - Update system packages
   - Review backup integrity
   - Update SSL certificates

3. **Quarterly**
   - Update Node.js and dependencies
   - Review security configurations
   - Performance optimization review

### Update Process

1. **Application Updates**
```bash
# Backup current version
cp -r /path/to/taskflow /path/to/taskflow-backup

# Pull latest changes
cd /path/to/taskflow
git pull origin main

# Install dependencies
npm install

# Run database migrations if needed
npm run db:push

# Build application
npm run build

# Restart application
pm2 restart taskflow
```

2. **System Updates**
```bash
# Update packages
sudo apt update && sudo apt upgrade -y

# Restart services if needed
sudo systemctl restart nginx
sudo systemctl restart postgresql
```

---

## Support

For additional support:

1. Check the [GitHub Issues](https://github.com/your-username/taskflow/issues)
2. Review application logs
3. Consult the [API Documentation](API.md)
4. Contact support team

---

**Note**: Replace `your-domain.com`, `your_secure_password`, and other placeholder values with your actual configuration details.