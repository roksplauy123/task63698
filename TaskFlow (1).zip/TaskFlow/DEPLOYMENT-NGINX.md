# TaskFlow - Nginx Deployment Guide

This guide provides detailed instructions for deploying TaskFlow on various Nginx configurations and control panels.

## Table of Contents
- [Standard Nginx Setup](#standard-nginx-setup)
- [Nginx with SSL/TLS](#nginx-with-ssltls)
- [cPanel with Nginx](#cpanel-with-nginx)
- [Plesk with Nginx](#plesk-with-nginx)
- [DirectAdmin with Nginx](#directadmin-with-nginx)
- [CloudPanel](#cloudpanel)
- [Performance Optimization](#performance-optimization)

---

## Standard Nginx Setup

### Complete Nginx Configuration

Create `/etc/nginx/sites-available/taskflow.conf`:

```nginx
# Main server block
server {
    listen 80;
    listen [::]:80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    ssl_trusted_certificate /etc/letsencrypt/live/your-domain.com/chain.pem;
    
    # SSL Security
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_session_tickets off;
    ssl_stapling on;
    ssl_stapling_verify on;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self';" always;
    
    # General Settings
    client_max_body_size 10M;
    client_body_buffer_size 1M;
    client_header_buffer_size 1k;
    large_client_header_buffers 4 4k;
    
    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;
    
    # Logging
    access_log /var/log/nginx/taskflow.access.log;
    error_log /var/log/nginx/taskflow.error.log;
    
    # Root location - Proxy to Node.js app
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering off;
    }
    
    # API Routes with enhanced settings
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
        
        # Rate limiting for API
        limit_req zone=api burst=20 nodelay;
        
        # CORS headers if needed
        add_header Access-Control-Allow-Origin "$http_origin" always;
        add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, PATCH, OPTIONS" always;
        add_header Access-Control-Allow-Headers "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization" always;
        add_header Access-Control-Expose-Headers "Content-Length,Content-Range" always;
        
        if ($request_method = 'OPTIONS') {
            add_header Content-Type text/plain;
            add_header Content-Length 0;
            return 204;
        }
    }
    
    # Static assets with caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Long-term caching
        expires 1y;
        add_header Cache-Control "public, immutable";
        add_header Vary "Accept-Encoding";
        
        # Optional: serve static files directly if available
        # try_files $uri @proxy;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        proxy_pass http://localhost:3000/health;
        proxy_set_header Host $host;
    }
    
    # Security: Deny access to sensitive files
    location ~ /\.(ht|git|env) {
        deny all;
        return 404;
    }
    
    # Security: Deny access to backup files
    location ~ \.(bak|config|sql|fla|psd|ini|log|sh|inc|swp|dist)$ {
        deny all;
        return 404;
    }
}

# Rate limiting zones
http {
    limit_req_zone $binary_remote_addr zone=api:10m rate=100r/m;
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;
}
```

### Enable the Configuration

```bash
# Create symbolic link
sudo ln -sf /etc/nginx/sites-available/taskflow.conf /etc/nginx/sites-enabled/

# Remove default site if needed
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

---

## Nginx with SSL/TLS

### Automatic SSL with Certbot

```bash
# Install Certbot
sudo apt update
sudo apt install snapd
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot

# Create symlink
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Get certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal setup
sudo systemctl enable snap.certbot.renew.timer
sudo systemctl start snap.certbot.renew.timer

# Test auto-renewal
sudo certbot renew --dry-run
```

### Manual SSL Configuration

If using custom certificates:

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;
    
    # Custom SSL certificates
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;
    ssl_certificate_chain /path/to/your/chain.crt;
    
    # SSL configuration continues...
}
```

---

## cPanel with Nginx

### Prerequisites
- cPanel server with WHM access
- Nginx enabled in WHM (if using cPanel with Nginx)
- Node.js selector available

### Step 1: Domain Setup
1. Log into cPanel
2. Go to "Subdomains" or use main domain
3. Create subdomain if needed (e.g., `app.yourdomain.com`)

### Step 2: Node.js Application Setup
1. Go to "Node.js Selector" in cPanel
2. Click "Create App"
3. Configure:
   - Node.js Version: 20.x
   - Application Mode: Production
   - Application Root: `taskflow` (or your chosen folder)
   - Application URL: your domain/subdomain
   - Startup File: `dist/index.js`

### Step 3: Upload Files
```bash
# Using cPanel File Manager or FTP
# Upload your built application to the application root folder
# Ensure dist/ folder contains the built application
```

### Step 4: Environment Variables
In Node.js Selector, add environment variables:
```
NODE_ENV=production
DATABASE_URL=postgresql://username_taskflow:password@localhost:5432/username_taskflow
PORT=3000
```

### Step 5: Database Setup
1. Go to "PostgreSQL Databases" in cPanel
2. Create database: `username_taskflow`
3. Create user: `username_taskflow_user`
4. Add user to database with all privileges

### Step 6: Custom Nginx Configuration (if applicable)
If you have access to Nginx configuration:

```bash
# Edit or create custom configuration
nano /etc/nginx/conf.d/custom_taskflow.conf
```

Add:
```nginx
location /taskflow/ {
    proxy_pass http://localhost:3000/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

---

## Plesk with Nginx

### Step 1: Domain Configuration
1. Log into Plesk Panel
2. Go to "Websites & Domains"
3. Add domain or subdomain for TaskFlow

### Step 2: Node.js Setup
1. Go to domain settings
2. Click "Node.js"
3. Enable Node.js support
4. Configure:
   - Node.js version: 20.x
   - Document root: `httpdocs`
   - Application root: `httpdocs`
   - Startup file: `dist/index.js`

### Step 3: Environment Variables
In Node.js settings, add:
```
NODE_ENV=production
DATABASE_URL=postgresql://taskflow_user:password@localhost:5432/taskflow_db
PORT=3000
```

### Step 4: Database Setup
1. Go to "Databases"
2. Create PostgreSQL database
3. Create database user
4. Note connection details

### Step 5: Custom Nginx Directives
1. Go to "Apache & Nginx Settings"
2. Add custom Nginx directives:

```nginx
location / {
    proxy_pass http://localhost:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_cache_bypass $http_upgrade;
}

location /api/ {
    proxy_pass http://localhost:3000/api/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

---

## DirectAdmin with Nginx

### Step 1: Domain Setup
1. Log into DirectAdmin
2. Go to "Domain Setup"
3. Add domain or subdomain

### Step 2: File Upload
1. Use "File Manager"
2. Upload application files to `public_html`
3. Extract files if uploaded as archive

### Step 3: Node.js Configuration
If Node.js support is available:
1. Go to "Node.js Setup"
2. Enable Node.js for the domain
3. Set startup script to `dist/index.js`
4. Configure environment variables

### Step 4: Custom Nginx Configuration
Create `.htaccess` file in document root:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
```

Or if you have access to custom Nginx configuration:
```nginx
location / {
    proxy_pass http://localhost:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

---

## CloudPanel

### Step 1: Site Creation
1. Log into CloudPanel
2. Go to "Sites"
3. Add new site with your domain

### Step 2: Node.js Application
1. Go to site settings
2. Enable "Node.js"
3. Configure:
   - Node.js Version: 20.x
   - App Port: 3000
   - Entry Point: `dist/index.js`

### Step 3: Environment Variables
Add in Node.js settings:
```
NODE_ENV=production
DATABASE_URL=postgresql://username:password@localhost:5432/database_name
```

### Step 4: Database Setup
1. Go to "Databases"
2. Create PostgreSQL database
3. Create user and assign privileges

### Step 5: Nginx Configuration
CloudPanel automatically configures Nginx, but you can add custom rules:

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:3000/api/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

---

## Performance Optimization

### Nginx Optimization

Add to `/etc/nginx/nginx.conf`:

```nginx
worker_processes auto;
worker_connections 1024;
worker_rlimit_nofile 2048;

events {
    use epoll;
    multi_accept on;
}

http {
    # Basic Settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Buffer Settings
    client_body_buffer_size 128k;
    client_max_body_size 10m;
    client_header_buffer_size 1k;
    large_client_header_buffers 4 4k;
    output_buffers 1 32k;
    postpone_output 1460;
    
    # Caching
    open_file_cache max=1000 inactive=20s;
    open_file_cache_valid 30s;
    open_file_cache_min_uses 2;
    open_file_cache_errors on;
    
    # Gzip Settings
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/x-javascript
        application/javascript
        application/xml+rss
        application/json;
    gzip_disable "MSIE [1-6]\.";
}
```

### SSL Optimization

```nginx
# SSL Session Cache
ssl_session_cache shared:SSL:50m;
ssl_session_timeout 1d;
ssl_session_tickets off;

# OCSP Stapling
ssl_stapling on;
ssl_stapling_verify on;
ssl_trusted_certificate /path/to/chain.pem;
resolver 8.8.8.8 8.8.4.4 valid=300s;
resolver_timeout 5s;
```

### Rate Limiting

```nginx
# Rate limiting configuration
limit_req_zone $binary_remote_addr zone=api:10m rate=100r/m;
limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;
limit_conn_zone $binary_remote_addr zone=conn_limit_per_ip:10m;

# Apply in server block
limit_req zone=api burst=20 nodelay;
limit_conn conn_limit_per_ip 20;
```

---

## Monitoring and Maintenance

### Log Rotation

Create `/etc/logrotate.d/taskflow`:

```
/var/log/nginx/taskflow.*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        if [ -f /var/run/nginx.pid ]; then
            kill -USR1 `cat /var/run/nginx.pid`
        fi
    endscript
}
```

### Health Checks

Add health check endpoint in your application and configure Nginx:

```nginx
location /health {
    access_log off;
    proxy_pass http://localhost:3000/health;
    proxy_set_header Host $host;
    
    # Return 503 if app is down
    proxy_intercept_errors on;
    error_page 502 503 504 = @maintenance;
}

location @maintenance {
    return 503 "Service temporarily unavailable";
    add_header Content-Type text/plain;
}
```

### Backup Configuration

```bash
#!/bin/bash
# Backup Nginx configuration
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/backups/nginx"
mkdir -p $BACKUP_DIR

tar -czf $BACKUP_DIR/nginx_config_$DATE.tar.gz /etc/nginx/
```

---

## Troubleshooting

### Common Nginx Issues

1. **502 Bad Gateway**
   - Check if Node.js app is running: `pm2 status`
   - Verify port configuration
   - Check Nginx error logs: `tail -f /var/log/nginx/error.log`

2. **SSL Certificate Issues**
   - Verify cert paths: `ls -la /etc/letsencrypt/live/your-domain.com/`
   - Test certificate: `nginx -t`
   - Check SSL configuration with: `openssl s_client -connect your-domain.com:443`

3. **Performance Issues**
   - Check worker processes: `ps aux | grep nginx`
   - Monitor connections: `netstat -an | grep :80 | wc -l`
   - Review access logs for slow requests

### Control Panel Specific Issues

1. **cPanel Issues**
   - Check Node.js selector logs
   - Verify app permissions
   - Ensure database connection

2. **Plesk Issues**
   - Check Plesk panel logs: `/var/log/plesk/panel.log`
   - Verify Node.js service status
   - Check domain DNS settings

For additional support, consult your control panel documentation or contact your hosting provider.