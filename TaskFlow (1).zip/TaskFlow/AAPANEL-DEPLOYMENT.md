# TaskFlow - aaPanel Deployment Guide

This comprehensive guide covers deploying TaskFlow on servers using aaPanel, a popular web hosting control panel.

## Table of Contents
- [Prerequisites](#prerequisites)
- [aaPanel Installation](#aapanel-installation)
- [Environment Setup](#environment-setup)
- [Database Configuration](#database-configuration)
- [Application Deployment](#application-deployment)
- [Web Server Configuration](#web-server-configuration)
- [SSL Setup](#ssl-setup)
- [Process Management](#process-management)
- [Monitoring and Maintenance](#monitoring-and-maintenance)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Server Requirements
- **OS**: Ubuntu 18.04+, CentOS 7+, or Debian 9+
- **RAM**: Minimum 1GB (2GB+ recommended)
- **Storage**: At least 10GB free space
- **Network**: Internet connection for package downloads
- **Access**: Root or sudo privileges

### Domain Requirements
- Domain name pointing to your server IP
- DNS properly configured

---

## aaPanel Installation

### Step 1: Install aaPanel

#### Ubuntu/Debian Installation
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install aaPanel
wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh
sudo bash install.sh aapanel

# Alternative secure installation
wget -O install.sh https://raw.githubusercontent.com/aaPanel/aaPanel/main/script/install_6.0_en.sh
sudo bash install.sh aapanel
```

#### CentOS/RHEL Installation
```bash
# Update system
sudo yum update -y

# Install aaPanel
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh
sudo bash install.sh aapanel
```

### Step 2: Initial Setup

1. **Access aaPanel**
   - After installation, note the panel URL, username, and password
   - Access via: `http://your-server-ip:7800`
   - Login with provided credentials

2. **Change Default Credentials**
   - Go to "Panel" → "Panel Settings"
   - Change username and password
   - Enable two-factor authentication (recommended)

3. **Update aaPanel**
   - Go to "Panel" → "Update"
   - Install latest version

---

## Environment Setup

### Step 1: Install Required Software

In aaPanel, go to "App Store" and install:

1. **Nginx** (Latest version)
   - Click "Install" next to Nginx
   - Wait for installation to complete

2. **PostgreSQL** (Version 13+)
   - Click "Install" next to PostgreSQL
   - Set root password during installation
   - Note the password for later use

3. **Node.js** (Version 18+)
   - Install Node.js from App Store
   - Or install via command line:
   ```bash
   # Install Node.js 20.x
   curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
   sudo yum install -y nodejs
   
   # Verify installation
   node --version
   npm --version
   ```

4. **PM2** (Process Manager)
   ```bash
   sudo npm install -g pm2
   ```

### Step 2: Configure Firewall

1. **aaPanel Firewall**
   - Go to "Security"
   - Add rules for:
     - Port 80 (HTTP)
     - Port 443 (HTTPS)
     - Port 3000 (Node.js app, temporary)

2. **System Firewall**
   ```bash
   # Ubuntu/Debian
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw allow 3000/tcp
   
   # CentOS/RHEL
   sudo firewall-cmd --permanent --add-port=80/tcp
   sudo firewall-cmd --permanent --add-port=443/tcp
   sudo firewall-cmd --permanent --add-port=3000/tcp
   sudo firewall-cmd --reload
   ```

---

## Database Configuration

### Step 1: Access PostgreSQL

1. **Via aaPanel Interface**
   - Go to "Database" → "PostgreSQL"
   - Click "Access" to open database management

2. **Via Command Line**
   ```bash
   # Switch to postgres user
   sudo -u postgres psql
   ```

### Step 2: Create Database and User

```sql
-- Create database
CREATE DATABASE taskflow;

-- Create user
CREATE USER taskflow_user WITH PASSWORD 'your_secure_password_here';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE taskflow TO taskflow_user;
ALTER USER taskflow_user CREATEDB;

-- Set connection limit (optional)
ALTER USER taskflow_user CONNECTION LIMIT 20;

-- Exit PostgreSQL
\q
```

### Step 3: Configure PostgreSQL

1. **Edit Configuration**
   ```bash
   # Find PostgreSQL config directory
   sudo -u postgres psql -c "SHOW config_file;"
   
   # Edit postgresql.conf
   sudo nano /www/server/pgsql/data/postgresql.conf
   ```

2. **Update Settings**
   ```ini
   # Connection settings
   listen_addresses = 'localhost'
   port = 5432
   max_connections = 100
   
   # Memory settings
   shared_buffers = 256MB
   effective_cache_size = 1GB
   work_mem = 4MB
   maintenance_work_mem = 64MB
   
   # Logging
   log_statement = 'all'
   log_min_duration_statement = 1000
   ```

3. **Configure Authentication**
   ```bash
   # Edit pg_hba.conf
   sudo nano /www/server/pgsql/data/pg_hba.conf
   ```
   
   Add line for local connections:
   ```
   local   taskflow    taskflow_user                   md5
   host    taskflow    taskflow_user   127.0.0.1/32    md5
   ```

4. **Restart PostgreSQL**
   ```bash
   # Via aaPanel: Database → PostgreSQL → Restart
   # Or via command line:
   sudo systemctl restart postgresql
   ```

---

## Application Deployment

### Step 1: Create Website in aaPanel

1. **Add Website**
   - Go to "Website" → "Add site"
   - Domain: `your-domain.com`
   - Document root: `/www/wwwroot/your-domain.com`
   - Enable SSL if needed

2. **Upload Application Files**
   - Use "File Manager" in aaPanel
   - Navigate to `/www/wwwroot/your-domain.com`
   - Upload your TaskFlow application files
   - Extract if uploaded as archive

### Step 2: Application Structure

Ensure your application structure in `/www/wwwroot/your-domain.com/`:
```
your-domain.com/
├── dist/                  # Built application
├── client/               # Frontend source
├── server/               # Backend source
├── shared/               # Shared schemas
├── package.json
├── .env
└── ecosystem.config.js   # PM2 configuration
```

### Step 3: Install Dependencies

```bash
# Navigate to application directory
cd /www/wwwroot/your-domain.com

# Install production dependencies
npm install --production

# Or if you need to build from source
npm install
npm run build
```

### Step 4: Environment Configuration

Create `.env` file:
```env
NODE_ENV=production
DATABASE_URL=postgresql://taskflow_user:your_secure_password_here@localhost:5432/taskflow
PORT=3000
PGHOST=localhost
PGPORT=5432
PGUSER=taskflow_user
PGPASSWORD=your_secure_password_here
PGDATABASE=taskflow
LOG_LEVEL=info
SESSION_SECRET=your-super-secure-session-secret-key-here
```

### Step 5: Database Setup

```bash
# Run database migrations
npm run db:push

# Or manually run schema if needed
```

### Step 6: Test Application

```bash
# Test application startup
node dist/index.js

# If successful, stop with Ctrl+C
```

---

## Web Server Configuration

### Step 1: Nginx Configuration via aaPanel

1. **Access Site Settings**
   - Go to "Website" → Click on your domain
   - Click "Site configuration"

2. **Configure Reverse Proxy**
   - Go to "Reverse proxy"
   - Add new proxy:
     ```
     Proxy name: TaskFlow
     Target URL: http://127.0.0.1:3000
     Send domain: $host
     ```

### Step 2: Manual Nginx Configuration

If you prefer manual configuration:

1. **Edit Nginx Config**
   ```bash
   # Find your site's Nginx config
   nano /www/server/panel/vhost/nginx/your-domain.com.conf
   ```

2. **Add Proxy Configuration**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com www.your-domain.com;
       
       # Security headers
       add_header X-Frame-Options "SAMEORIGIN" always;
       add_header X-XSS-Protection "1; mode=block" always;
       add_header X-Content-Type-Options "nosniff" always;
       add_header Referrer-Policy "no-referrer-when-downgrade" always;
       
       # Gzip compression
       gzip on;
       gzip_vary on;
       gzip_min_length 1024;
       gzip_proxied any;
       gzip_comp_level 6;
       gzip_types
           text/plain
           text/css
           text/xml
           text/javascript
           application/json
           application/javascript
           application/xml+rss
           application/atom+xml
           image/svg+xml;
       
       # Main application proxy
       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
           proxy_connect_timeout 60s;
           proxy_send_timeout 60s;
           proxy_read_timeout 60s;
       }
       
       # API routes with rate limiting
       location /api/ {
           proxy_pass http://127.0.0.1:3000/api/;
           proxy_http_version 1.1;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           
           # Rate limiting (configure in nginx.conf first)
           # limit_req zone=api burst=20 nodelay;
       }
       
       # Static files with long-term caching
       location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           expires 1y;
           add_header Cache-Control "public, immutable";
       }
       
       # Health check
       location /health {
           proxy_pass http://127.0.0.1:3000/health;
           access_log off;
       }
   }
   ```

3. **Test and Reload Nginx**
   ```bash
   # Test configuration
   nginx -t
   
   # Reload Nginx via aaPanel or command line
   systemctl reload nginx
   ```

---

## SSL Setup

### Step 1: SSL via aaPanel (Recommended)

1. **Let's Encrypt SSL**
   - Go to your website settings
   - Click "SSL"
   - Click "Let's Encrypt"
   - Enter your email and domain
   - Click "Apply"

2. **Force HTTPS**
   - In SSL settings, enable "Force HTTPS"
   - This automatically redirects HTTP to HTTPS

### Step 2: Manual SSL Configuration

If you prefer manual setup:

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

---

## Process Management

### Step 1: PM2 Configuration

Create `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'taskflow',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development',
      PORT: 3000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    // Logging
    error_file: '/www/wwwroot/your-domain.com/logs/err.log',
    out_file: '/www/wwwroot/your-domain.com/logs/out.log',
    log_file: '/www/wwwroot/your-domain.com/logs/combined.log',
    time: true,
    
    // Process management
    max_memory_restart: '1G',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s',
    
    // Auto restart
    watch: false,
    ignore_watch: ['node_modules', 'logs']
  }]
};
```

### Step 2: Start Application with PM2

```bash
# Navigate to app directory
cd /www/wwwroot/your-domain.com

# Create logs directory
mkdir -p logs

# Start application
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save

# Set up PM2 to start on boot
pm2 startup
# Follow the instructions shown
```

### Step 3: PM2 Management Commands

```bash
# View application status
pm2 status

# View logs
pm2 logs taskflow

# Restart application
pm2 restart taskflow

# Stop application
pm2 stop taskflow

# Monitor application
pm2 monit

# View detailed info
pm2 describe taskflow
```

---

## Monitoring and Maintenance

### Step 1: aaPanel Monitoring

1. **System Monitor**
   - Go to "Monitor" in aaPanel
   - View CPU, memory, and disk usage
   - Set up alerts if needed

2. **Website Monitor**
   - Go to "Website" → "Monitor"
   - Add your domain for uptime monitoring

### Step 2: Application Monitoring

1. **PM2 Monitoring**
   ```bash
   # Install PM2 monitoring tools
   pm2 install pm2-logrotate
   pm2 set pm2-logrotate:max_size 10M
   pm2 set pm2-logrotate:compress true
   pm2 set pm2-logrotate:retain 7
   ```

2. **Health Check Endpoint**
   Ensure your application has a health check at `/health`:
   ```javascript
   app.get('/health', (req, res) => {
     res.status(200).json({
       status: 'OK',
       timestamp: new Date().toISOString(),
       uptime: process.uptime(),
       environment: process.env.NODE_ENV,
       database: 'connected' // Add actual DB check
     });
   });
   ```

### Step 3: Backup Configuration

1. **Database Backup Script**
   ```bash
   #!/bin/bash
   # /www/backup/taskflow-db-backup.sh
   
   DATE=$(date +%Y%m%d_%H%M%S)
   BACKUP_DIR="/www/backup/database"
   DB_NAME="taskflow"
   DB_USER="taskflow_user"
   
   mkdir -p $BACKUP_DIR
   
   # Create backup
   pg_dump -h localhost -U $DB_USER -d $DB_NAME -f $BACKUP_DIR/taskflow_$DATE.sql
   
   # Compress backup
   gzip $BACKUP_DIR/taskflow_$DATE.sql
   
   # Remove old backups (keep 7 days)
   find $BACKUP_DIR -name "taskflow_*.sql.gz" -mtime +7 -delete
   
   echo "$(date): Database backup completed" >> /www/logs/backup.log
   ```

2. **Application Backup**
   ```bash
   #!/bin/bash
   # /www/backup/taskflow-app-backup.sh
   
   DATE=$(date +%Y%m%d_%H%M%S)
   BACKUP_DIR="/www/backup/application"
   APP_DIR="/www/wwwroot/your-domain.com"
   
   mkdir -p $BACKUP_DIR
   
   # Backup application files (excluding node_modules)
   tar --exclude='node_modules' --exclude='logs' -czf $BACKUP_DIR/taskflow_app_$DATE.tar.gz $APP_DIR
   
   # Remove old backups
   find $BACKUP_DIR -name "taskflow_app_*.tar.gz" -mtime +7 -delete
   
   echo "$(date): Application backup completed" >> /www/logs/backup.log
   ```

3. **Schedule Backups**
   ```bash
   # Add to crontab
   crontab -e
   
   # Add these lines:
   0 2 * * * /www/backup/taskflow-db-backup.sh
   0 3 * * * /www/backup/taskflow-app-backup.sh
   ```

---

## Troubleshooting

### Common Issues

#### 1. Application Won't Start

**Check PM2 Status:**
```bash
pm2 status
pm2 logs taskflow
```

**Common Solutions:**
- Verify database connection in `.env`
- Check port 3000 is not in use: `netstat -tulpn | grep :3000`
- Ensure dependencies are installed: `npm install --production`
- Check file permissions: `chown -R www:www /www/wwwroot/your-domain.com`

#### 2. Database Connection Issues

**Test Database Connection:**
```bash
# Test PostgreSQL connection
psql -h localhost -U taskflow_user -d taskflow

# Check PostgreSQL status
systemctl status postgresql
```

**Common Solutions:**
- Verify database credentials in `.env`
- Check PostgreSQL is running
- Verify `pg_hba.conf` authentication settings
- Check firewall rules

#### 3. Nginx Configuration Issues

**Test Nginx Config:**
```bash
nginx -t
```

**Check Nginx Logs:**
```bash
tail -f /www/wwwlogs/your-domain.com.log
tail -f /www/wwwlogs/your-domain.com.error.log
```

**Common Solutions:**
- Verify proxy_pass URL is correct
- Check if Node.js app is running on port 3000
- Ensure proper proxy headers are set

#### 4. SSL Certificate Issues

**Check Certificate Status:**
```bash
# Via aaPanel: Website → SSL → View certificate details
# Or check expiration:
openssl s_client -connect your-domain.com:443 -servername your-domain.com
```

**Common Solutions:**
- Renew Let's Encrypt certificate via aaPanel
- Check domain DNS settings
- Verify certificate files exist and are readable

#### 5. Performance Issues

**Monitor Resources:**
```bash
# Check system resources
htop
df -h
free -m

# Check PM2 processes
pm2 monit
```

**Common Solutions:**
- Increase server resources if needed
- Optimize database queries
- Enable Nginx caching
- Use PM2 cluster mode for better CPU utilization

### Performance Optimization

#### 1. Nginx Optimization

Add to your Nginx config:
```nginx
# Enable gzip compression
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_comp_level 6;

# Enable browser caching
location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}

# Enable keep-alive connections
keepalive_timeout 65;
keepalive_requests 100;
```

#### 2. PostgreSQL Optimization

```sql
-- Add indexes for better performance
CREATE INDEX CONCURRENTLY idx_tasks_completed ON tasks(completed);
CREATE INDEX CONCURRENTLY idx_tasks_created_at ON tasks(created_at DESC);

-- Update statistics
ANALYZE tasks;
```

#### 3. PM2 Optimization

```javascript
// In ecosystem.config.js
module.exports = {
  apps: [{
    name: 'taskflow',
    script: 'dist/index.js',
    instances: 'max', // Use all CPU cores
    exec_mode: 'cluster',
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024'
  }]
};
```

---

## Security Best Practices

### 1. aaPanel Security

- Change default SSH port
- Enable fail2ban
- Update aaPanel regularly
- Use strong passwords
- Enable 2FA

### 2. Application Security

- Keep Node.js and dependencies updated
- Use environment variables for secrets
- Enable rate limiting
- Configure proper CORS headers
- Use HTTPS only

### 3. Database Security

- Use strong database passwords
- Limit database connections
- Regular security updates
- Monitor database logs

---

## Maintenance Tasks

### Daily
- Monitor application logs
- Check system resources
- Verify backup completion

### Weekly
- Review security logs
- Update dependencies if needed
- Check SSL certificate expiration

### Monthly
- Update system packages
- Review performance metrics
- Clean up old log files

---

Your TaskFlow application is now successfully deployed on aaPanel! The setup includes proper process management with PM2, SSL encryption, database optimization, and comprehensive monitoring. The application will automatically restart on server reboots and handle traffic efficiently through Nginx reverse proxy.