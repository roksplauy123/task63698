# GitHub Repository Setup Guide

This guide will help you add your TaskFlow application to GitHub and set up version control.

## Step 1: Create a New GitHub Repository

### Option A: Using GitHub Web Interface

1. **Go to GitHub**
   - Visit [github.com](https://github.com)
   - Log in to your account
   - Click the "+" icon in the top right corner
   - Select "New repository"

2. **Repository Settings**
   ```
   Repository name: taskflow
   Description: A modern task management application with PostgreSQL persistence
   Visibility: Public (or Private if you prefer)
   
   ✅ Add a README file: NO (we already have one)
   ✅ Add .gitignore: NO (we already have one)
   ✅ Choose a license: NO (we already have MIT license)
   ```

3. **Create Repository**
   - Click "Create repository"
   - Copy the repository URL (you'll need this)

### Option B: Using GitHub CLI (if installed)

```bash
# Create repository directly from command line
gh repo create taskflow --public --description "A modern task management application with PostgreSQL persistence"
```

## Step 2: Initialize Git and Connect to GitHub

### From Your Project Directory

1. **Initialize Git Repository**
   ```bash
   git init
   ```

2. **Add All Files**
   ```bash
   git add .
   ```

3. **Make Initial Commit**
   ```bash
   git commit -m "Initial commit: TaskFlow - Modern task management application

   Features:
   - React + TypeScript frontend with responsive design
   - Express.js + PostgreSQL backend
   - Real-time task management with CRUD operations
   - Comprehensive deployment documentation
   - Support for multiple deployment methods (Nginx, Docker, Control Panels)"
   ```

4. **Add Remote Origin**
   ```bash
   # Replace 'yourusername' with your actual GitHub username
   git remote add origin https://github.com/yourusername/taskflow.git
   ```

5. **Push to GitHub**
   ```bash
   git branch -M main
   git push -u origin main
   ```

## Step 3: Repository Configuration

### GitHub Repository Settings

1. **Go to Repository Settings**
   - Navigate to your repository on GitHub
   - Click "Settings" tab

2. **Configure Repository**
   
   **General Settings:**
   - Repository name: `taskflow`
   - Description: `A modern task management application with PostgreSQL persistence`
   - Website: Add your deployed app URL (optional)
   - Topics: Add relevant tags like `task-management`, `react`, `postgresql`, `typescript`, `express`

   **Features:**
   - ✅ Enable Wikis (for additional documentation)
   - ✅ Enable Issues (for bug tracking)
   - ✅ Enable Projects (for project management)
   - ✅ Enable Discussions (for community)

   **Security:**
   - ✅ Enable vulnerability alerts
   - ✅ Enable automated security updates

3. **Branch Protection (Recommended)**
   - Go to "Branches" in settings
   - Add rule for `main` branch:
     - ✅ Require pull request reviews before merging
     - ✅ Dismiss stale PR approvals when new commits are pushed
     - ✅ Require status checks to pass before merging

## Step 4: Add Repository Secrets (For CI/CD)

If you plan to set up automated deployment:

1. **Go to Repository Settings > Secrets and variables > Actions**

2. **Add Repository Secrets:**
   ```
   DATABASE_URL: postgresql://user:password@host:5432/database
   SESSION_SECRET: your-secure-session-secret
   DEPLOY_HOST: your-server-ip-or-domain
   DEPLOY_USER: your-deploy-username
   DEPLOY_KEY: your-ssh-private-key (for deployments)
   ```

## Step 5: Create GitHub Pages (Optional)

To host documentation on GitHub Pages:

1. **Go to Repository Settings > Pages**
2. **Source:** Deploy from a branch
3. **Branch:** main
4. **Folder:** / (root) or /docs
5. **Save**

Your documentation will be available at: `https://yourusername.github.io/taskflow/`

## Step 6: Set Up GitHub Actions (Optional)

Create automated workflows for testing and deployment:

### Create `.github/workflows/ci.yml`

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: taskflow_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run type check
      run: npm run type-check
    
    - name: Run linting
      run: npm run lint
    
    - name: Build application
      run: npm run build
      env:
        NODE_ENV: production
        DATABASE_URL: postgresql://postgres:postgres@localhost:5432/taskflow_test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build application
      run: npm run build
      env:
        NODE_ENV: production
    
    - name: Deploy to server
      uses: appleboy/ssh-action@v1.0.0
      with:
        host: ${{ secrets.DEPLOY_HOST }}
        username: ${{ secrets.DEPLOY_USER }}
        key: ${{ secrets.DEPLOY_KEY }}
        script: |
          cd /opt/taskflow
          git pull origin main
          npm install --production
          npm run build
          pm2 restart taskflow
```

## Step 7: Add Issue Templates

Create `.github/ISSUE_TEMPLATE/bug_report.md`:

```markdown
---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment:**
 - OS: [e.g. iOS]
 - Browser [e.g. chrome, safari]
 - Version [e.g. 22]
 - Node.js version: [e.g. 20.x]
 - Database: [e.g. PostgreSQL 15]

**Additional context**
Add any other context about the problem here.
```

Create `.github/ISSUE_TEMPLATE/feature_request.md`:

```markdown
---
name: Feature request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Additional context**
Add any other context or screenshots about the feature request here.
```

## Step 8: Create Pull Request Template

Create `.github/PULL_REQUEST_TEMPLATE.md`:

```markdown
## Description
Brief description of changes made in this PR.

## Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring

## Testing
- [ ] Tests have been added/updated
- [ ] All tests pass locally
- [ ] Manual testing completed

## Checklist
- [ ] Code follows the project's style guidelines
- [ ] Self-review of my own code completed
- [ ] Code is properly commented
- [ ] Corresponding documentation has been updated
- [ ] No new warnings or errors introduced

## Screenshots (if applicable)
Add screenshots to help explain your changes.

## Additional Notes
Any additional information that reviewers should know.
```

## Step 9: Repository Management Commands

### Useful Git Commands

```bash
# Check repository status
git status

# Add specific files
git add filename.js

# Add all changes
git add .

# Commit changes
git commit -m "Your commit message"

# Push changes
git push origin main

# Pull latest changes
git pull origin main

# Create and switch to new branch
git checkout -b feature/new-feature

# Switch between branches
git checkout main
git checkout feature/new-feature

# Merge branch
git checkout main
git merge feature/new-feature

# Delete branch
git branch -d feature/new-feature

# View commit history
git log --oneline

# View remote repositories
git remote -v

# Tag a release
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

### Branch Strategy

Recommended branching strategy:

```
main          # Production-ready code
├── develop   # Integration branch
├── feature/* # Feature branches
├── hotfix/*  # Quick fixes
└── release/* # Release preparation
```

## Step 10: Release Management

### Creating Releases

1. **Prepare Release**
   ```bash
   # Update version in package.json
   npm version patch  # or minor/major
   
   # Build and test
   npm run build
   npm test
   
   # Commit version bump
   git add package.json package-lock.json
   git commit -m "Bump version to $(node -p "require('./package.json').version")"
   
   # Create tag
   git tag -a v$(node -p "require('./package.json').version") -m "Release version $(node -p "require('./package.json').version")"
   
   # Push changes and tags
   git push origin main --tags
   ```

2. **Create GitHub Release**
   - Go to your repository on GitHub
   - Click "Releases" → "Create a new release"
   - Choose the tag you created
   - Add release notes describing changes
   - Attach any additional files if needed
   - Publish release

## Step 11: Collaboration Setup

### Contributor Guidelines

Create `CONTRIBUTING.md`:

```markdown
# Contributing to TaskFlow

Thank you for considering contributing to TaskFlow! This document outlines the process for contributing to this project.

## Development Setup

1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/taskflow.git`
3. Install dependencies: `npm install`
4. Create a feature branch: `git checkout -b feature/your-feature`
5. Make your changes
6. Test your changes: `npm test`
7. Commit your changes: `git commit -m "Description of changes"`
8. Push to your fork: `git push origin feature/your-feature`
9. Create a Pull Request

## Code Style

- Use TypeScript for type safety
- Follow existing code formatting
- Add tests for new features
- Update documentation as needed

## Reporting Issues

Use the GitHub issue tracker to report bugs or request features.
```

## Troubleshooting

### Common Issues

1. **Authentication Issues**
   ```bash
   # Set up SSH keys for easier authentication
   ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
   
   # Add to GitHub: Settings > SSH and GPG keys
   ```

2. **Large Files**
   ```bash
   # Use Git LFS for large files
   git lfs install
   git lfs track "*.zip"
   git add .gitattributes
   ```

3. **Merge Conflicts**
   ```bash
   # Resolve conflicts manually, then:
   git add conflicted-file.js
   git commit -m "Resolve merge conflict"
   ```

## Next Steps

After setting up your GitHub repository:

1. **Share your repository** with the development community
2. **Set up monitoring** and error tracking
3. **Create a project board** for issue management
4. **Write more detailed documentation** in the Wiki
5. **Set up automated testing** and deployment
6. **Add badges** to your README for build status, coverage, etc.

Your TaskFlow application is now ready for collaborative development and deployment!