# TaskFlow - Task Management Application

## Overview

TaskFlow is a modern, full-stack task management application built with React, Express, and PostgreSQL. The application provides a clean, intuitive interface for managing tasks with features like creating, updating, completing, and deleting tasks. It uses a monorepo structure with shared schemas and follows modern development practices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Overall Architecture
The application follows a modern full-stack architecture with clear separation between client, server, and shared components:

- **Frontend**: React-based SPA with TypeScript
- **Backend**: Express.js REST API server
- **Database**: PostgreSQL with Drizzle ORM
- **Shared**: Common schemas and types
- **Build System**: Vite for frontend bundling, esbuild for backend

### Directory Structure
```
├── client/               # React frontend application
├── server/               # Express.js backend API
├── shared/               # Shared schemas and types
├── migrations/           # Database migrations
└── dist/                 # Production build output
```

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing  
- **UI Library**: Radix UI components with shadcn/ui styling
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Forms**: React Hook Form with Zod validation

**Key Frontend Features**:
- Task creation, editing, and deletion
- Task filtering (all, active, completed)
- Real-time task statistics
- Toast notifications for user feedback
- Responsive design with mobile support
- Loading states and optimistic updates

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Connection**: Neon serverless PostgreSQL
- **API Design**: RESTful endpoints with JSON responses
- **Validation**: Zod schemas for request validation
- **Error Handling**: Centralized error middleware

**API Endpoints**:
- `GET /api/tasks` - Retrieve all tasks
- `GET /api/tasks/:id` - Retrieve single task
- `POST /api/tasks` - Create new task
- `PATCH /api/tasks/:id` - Update task
- `DELETE /api/tasks/:id` - Delete task

### Data Schema
The application uses a simple task-based data model:

**Tasks Table**:
- `id` (UUID, Primary Key)
- `title` (Text, Required)
- `description` (Text, Optional)
- `completed` (Boolean, Default: false)
- `createdAt` (Timestamp)
- `updatedAt` (Timestamp)

**Users Table** (Defined but not fully implemented):
- `id` (UUID, Primary Key)
- `username` (Text, Unique)
- `password` (Text)

## Data Flow

1. **Client Request**: React components trigger API calls through TanStack Query
2. **API Processing**: Express routes validate requests using Zod schemas
3. **Database Operations**: Drizzle ORM handles PostgreSQL interactions
4. **Response**: JSON data flows back through the API to update client state
5. **UI Updates**: React components re-render with new data

The application uses optimistic updates for better user experience, immediately updating the UI while API calls are in progress.

## External Dependencies

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database
- **Connection**: Uses connection pooling via `@neondatabase/serverless`
- **ORM**: Drizzle for type-safe database operations

### UI/UX Libraries
- **Radix UI**: Unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **date-fns**: Date manipulation utilities

### Development Tools
- **Vite**: Frontend build tool with HMR
- **TypeScript**: Type safety across the stack
- **Zod**: Runtime validation and type inference
- **Drizzle Kit**: Database migrations and schema management

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR at client root
- **Backend**: tsx for TypeScript execution in development
- **Database**: Drizzle migrations for schema management
- **Environment**: NODE_ENV-based configuration

### Production Build Process
1. **Frontend**: `vite build` creates optimized client bundle in `dist/public`
2. **Backend**: `esbuild` bundles server code to `dist/index.js`
3. **Static Serving**: Express serves frontend assets in production
4. **Database**: Migrations applied via `drizzle-kit push`

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment detection (development/production)
- Build commands handle both development and production scenarios

### Deployment Options
The application supports multiple deployment methods:

1. **Manual Nginx Installation**: Complete server setup with PostgreSQL, PM2, and SSL
2. **Control Panel Deployment**: Support for cPanel, Plesk, DirectAdmin, CloudPanel, ISPConfig
3. **Docker Deployment**: Containerized deployment with docker-compose
4. **Replit Deployment**: One-click deployment through Replit's deployment system

**Documentation Files**:
- `INSTALLATION.md`: Comprehensive installation guide covering all deployment methods
- `DEPLOYMENT-NGINX.md`: Detailed Nginx configuration and optimization
- `CONTROL-PANEL-DEPLOYMENT.md`: Step-by-step guides for popular hosting control panels
- `AAPANEL-DEPLOYMENT.md`: Complete aaPanel hosting control panel deployment guide

### Key Architectural Decisions

**Monorepo Structure**: Chosen to share TypeScript types and schemas between client and server, reducing duplication and ensuring consistency.

**Drizzle ORM**: Selected over alternatives like Prisma for better TypeScript integration and lighter runtime footprint.

**TanStack Query**: Provides excellent caching, background updates, and optimistic updates for better UX.

**Zod Validation**: Ensures runtime type safety and provides seamless integration with TypeScript types.

**Radix + Tailwind**: Combines accessible, unstyled components with utility-first styling for maximum customization.

The application prioritizes developer experience, type safety, and user experience while maintaining a simple, maintainable codebase.