# TaskFlow - Control Panel Deployment Guide

This guide covers deployment on popular web hosting control panels with step-by-step instructions and troubleshooting tips.

## Table of Contents
- [cPanel/WHM Deployment](#cpanelwhm-deployment)
- [Plesk Panel Deployment](#plesk-panel-deployment)
- [DirectAdmin Deployment](#directadmin-deployment)
- [CloudPanel Deployment](#cloudpanel-deployment)
- [ISPConfig Deployment](#ispconfig-deployment)
- [Webmin/Virtualmin Deployment](#webminvirtualmin-deployment)
- [Generic Panel Deployment](#generic-panel-deployment)

---

## cPanel/WHM Deployment

### Prerequisites
- cPanel account with Node.js support
- PostgreSQL or MySQL database access
- SSH access (optional but recommended)
- Domain or subdomain configured

### Step 1: Prepare Application Files

1. **Build the Application Locally**
```bash
# On your local machine
git clone https://github.com/your-username/taskflow.git
cd taskflow
npm install
npm run build
```

2. **Create Deployment Package**
```bash
# Create deployment archive
tar -czf taskflow-deploy.tar.gz \
    dist/ \
    package.json \
    package-lock.json \
    .env.example \
    ecosystem.config.js
```

### Step 2: Upload to cPanel

1. **Access File Manager**
   - Log into cPanel
   - Open "File Manager"
   - Navigate to your domain's folder (usually `public_html` or subdomain folder)

2. **Upload and Extract**
   - Upload `taskflow-deploy.tar.gz`
   - Extract the archive
   - Set proper permissions (755 for folders, 644 for files)

### Step 3: Database Setup

1. **Create Database**
   - Go to "PostgreSQL Databases" (or MySQL if preferred)
   - Create database: `username_taskflow`
   - Create user: `username_taskflow_user`
   - Add user to database with ALL PRIVILEGES

2. **Note Database Details**
   ```
   Database: username_taskflow
   Username: username_taskflow_user
   Password: [your_secure_password]
   Host: localhost
   Port: 5432 (PostgreSQL) or 3306 (MySQL)
   ```

### Step 4: Node.js Application Setup

1. **Access Node.js Selector**
   - Go to "Node.js Selector" in cPanel
   - Click "CREATE APP"

2. **Configure Application**
   ```
   Node.js Version: 20.x or latest LTS
   Application Mode: Production
   Application Root: taskflow (or your chosen folder)
   Application URL: your domain or subdomain
   Startup File: dist/index.js
   ```

3. **Set Environment Variables**
   Add these variables in the Node.js app settings:
   ```
   NODE_ENV=production
   DATABASE_URL=postgresql://username_taskflow_user:password@localhost:5432/username_taskflow
   PORT=3000
   PGHOST=localhost
   PGPORT=5432
   PGUSER=username_taskflow_user
   PGPASSWORD=your_secure_password
   PGDATABASE=username_taskflow
   ```

### Step 5: Install Dependencies

1. **Using Node.js Selector**
   - In the app settings, click "NPM Install"
   - Wait for dependencies to install

2. **Or via SSH** (if available)
   ```bash
   cd ~/public_html/taskflow
   npm install --production
   ```

### Step 6: Database Migration

1. **Run Database Setup**
   ```bash
   # Via SSH
   cd ~/public_html/taskflow
   npm run db:push
   ```

2. **Or manually run SQL**
   - Use cPanel's phpPgAdmin or similar
   - Execute the SQL schema manually

### Step 7: Start Application

1. **Start via Node.js Selector**
   - Click "START APP" in the Node.js selector
   - Monitor the app status

2. **Configure .htaccess** (if needed)
   Create `.htaccess` in domain root:
   ```apache
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
   
   # Enable compression
   <IfModule mod_deflate.c>
       AddOutputFilterByType DEFLATE text/plain
       AddOutputFilterByType DEFLATE text/html
       AddOutputFilterByType DEFLATE text/xml
       AddOutputFilterByType DEFLATE text/css
       AddOutputFilterByType DEFLATE application/xml
       AddOutputFilterByType DEFLATE application/xhtml+xml
       AddOutputFilterByType DEFLATE application/rss+xml
       AddOutputFilterByType DEFLATE application/javascript
       AddOutputFilterByType DEFLATE application/x-javascript
   </IfModule>
   
   # Cache static files
   <IfModule mod_expires.c>
       ExpiresActive On
       ExpiresByType text/css "access plus 1 year"
       ExpiresByType application/javascript "access plus 1 year"
       ExpiresByType image/png "access plus 1 year"
       ExpiresByType image/jpg "access plus 1 year"
       ExpiresByType image/jpeg "access plus 1 year"
       ExpiresByType image/gif "access plus 1 year"
       ExpiresByType image/svg+xml "access plus 1 year"
   </IfModule>
   ```

### Step 8: SSL Setup

1. **Free SSL via cPanel**
   - Go to "SSL/TLS"
   - Use "Let's Encrypt" if available
   - Or upload custom certificates

2. **Force HTTPS**
   Add to `.htaccess`:
   ```apache
   RewriteEngine On
   RewriteCond %{HTTPS} off
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

---

## Plesk Panel Deployment

### Step 1: Domain Configuration

1. **Add Domain**
   - Log into Plesk
   - Go to "Websites & Domains"
   - Add domain or subdomain

2. **Configure Document Root**
   - Set document root to `httpdocs`
   - Ensure PHP is disabled for this domain (optional)

### Step 2: Node.js Setup

1. **Enable Node.js**
   - Go to domain settings
   - Click "Node.js"
   - Enable Node.js support

2. **Configure Node.js**
   ```
   Node.js version: 20.x or latest
   Document root: httpdocs
   Application root: httpdocs
   Application URL: / (or subdirectory)
   Startup file: dist/index.js
   ```

### Step 3: Upload Application

1. **File Manager Upload**
   - Use Plesk File Manager
   - Upload built application to `httpdocs`
   - Extract files if uploaded as archive

2. **Set Permissions**
   - Ensure files have correct permissions
   - Usually 644 for files, 755 for directories

### Step 4: Database Configuration

1. **Create Database**
   - Go to "Databases"
   - Add PostgreSQL database
   - Create database user
   - Grant necessary privileges

2. **Environment Variables**
   In Node.js settings, add:
   ```
   NODE_ENV=production
   DATABASE_URL=postgresql://dbuser:password@localhost:5432/dbname
   PORT=3000
   ```

### Step 5: Custom Nginx Directives

1. **Apache & Nginx Settings**
   - Go to "Apache & Nginx Settings"
   - Add custom Nginx directives:

   ```nginx
   location / {
       proxy_pass http://localhost:3000;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_cache_bypass $http_upgrade;
       proxy_connect_timeout 60s;
       proxy_send_timeout 60s;
       proxy_read_timeout 60s;
   }
   
   location /api/ {
       proxy_pass http://localhost:3000/api/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       
       # Rate limiting
       limit_req zone=api burst=20 nodelay;
   }
   
   # Static files caching
   location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
       proxy_pass http://localhost:3000;
       proxy_set_header Host $host;
       expires 1y;
       add_header Cache-Control "public, immutable";
   }
   ```

### Step 6: Start Application

1. **Install Dependencies**
   - In Node.js settings, run npm install
   - Or use SSH if available

2. **Start Application**
   - Click "Enable Node.js" and "Restart App"
   - Monitor application logs

---

## DirectAdmin Deployment

### Step 1: Domain Setup

1. **Create Domain/Subdomain**
   - Log into DirectAdmin
   - Go to "Subdomain Management" or use main domain
   - Create subdomain if needed

### Step 2: File Upload

1. **File Manager**
   - Use DirectAdmin File Manager
   - Navigate to `public_html` or subdomain folder
   - Upload application files

2. **Extract Files**
   ```bash
   # Via SSH if available
   cd ~/domains/yourdomain.com/public_html
   tar -xzf taskflow-deploy.tar.gz
   ```

### Step 3: Database Setup

1. **Create Database**
   - Go to "PostgreSQL Management" or "MySQL Management"
   - Create database and user
   - Note connection details

### Step 4: Node.js Configuration

**If Node.js support is available:**

1. **Node.js Setup**
   - Go to "Node.js Setup" (if available)
   - Configure Node.js version and startup script

2. **Environment Variables**
   ```
   NODE_ENV=production
   DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
   PORT=3000
   ```

**If Node.js is not directly supported:**

1. **Manual Installation via SSH**
   ```bash
   # Install Node.js via Node Version Manager
   curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
   source ~/.bashrc
   nvm install 20
   nvm use 20
   
   # Install PM2
   npm install -g pm2
   
   # Start application
   cd ~/domains/yourdomain.com/public_html/taskflow
   npm install --production
   pm2 start dist/index.js --name taskflow
   ```

### Step 5: Web Server Configuration

1. **Apache Configuration**
   Create `.htaccess` in document root:
   ```apache
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
   
   # Security headers
   Header always set X-Frame-Options SAMEORIGIN
   Header always set X-Content-Type-Options nosniff
   Header always set X-XSS-Protection "1; mode=block"
   ```

---

## CloudPanel Deployment

### Step 1: Site Creation

1. **Add Site**
   - Log into CloudPanel
   - Go to "Sites"
   - Add new site with your domain

2. **Site Configuration**
   - Choose "Node.js" as site type
   - Configure domain settings

### Step 2: Node.js Application

1. **Node.js Settings**
   - Go to site settings
   - Enable "Node.js"
   - Configure:
     ```
     Node.js Version: 20.x
     App Port: 3000
     Document Root: /
     Entry Point: dist/index.js
     ```

### Step 3: File Upload

1. **File Manager**
   - Use CloudPanel File Manager
   - Upload application files to site root
   - Extract if necessary

### Step 4: Environment Configuration

1. **Environment Variables**
   In Node.js settings, add:
   ```
   NODE_ENV=production
   DATABASE_URL=postgresql://username:password@localhost:5432/database_name
   PORT=3000
   ```

### Step 5: Database Setup

1. **Create Database**
   - Go to "Databases"
   - Create PostgreSQL database
   - Create user and assign privileges

### Step 6: Start Application

1. **Install Dependencies**
   ```bash
   # Via SSH or terminal
   cd /home/cloudpanel/htdocs/yourdomain.com
   npm install --production
   ```

2. **Start Application**
   - Use CloudPanel interface to start/restart app
   - Monitor application status

---

## ISPConfig Deployment

### Step 1: Website Setup

1. **Create Website**
   - Log into ISPConfig
   - Go to "Sites" > "Website"
   - Add new website

2. **Configure Options**
   - Enable SSL if needed
   - Set document root
   - Configure DNS if managing domains

### Step 2: Database Configuration

1. **Database Setup**
   - Go to "Sites" > "Database"
   - Create PostgreSQL database
   - Create database user

### Step 3: Application Deployment

1. **Upload Files**
   - Use FTP or File Manager
   - Upload to website document root

2. **Node.js Setup** (if supported)
   - Configure Node.js version
   - Set startup script
   - Add environment variables

### Step 4: Web Server Configuration

1. **Apache/Nginx Configuration**
   Add custom configuration for proxy:
   ```
   ProxyPass / http://localhost:3000/
   ProxyPassReverse / http://localhost:3000/
   ProxyPreserveHost On
   ```

---

## Webmin/Virtualmin Deployment

### Step 1: Virtual Server Setup

1. **Create Virtual Server**
   - Log into Virtualmin
   - Create new virtual server
   - Configure domain settings

### Step 2: Application Setup

1. **Upload Files**
   - Use File Manager or FTP
   - Upload to `public_html`

2. **Database Creation**
   - Go to database management
   - Create PostgreSQL database and user

### Step 3: Node.js Configuration

1. **Install Node.js** (if not available)
   ```bash
   # Via SSH
   curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
   source ~/.bashrc
   nvm install 20
   ```

2. **Configure Application**
   - Set environment variables
   - Install dependencies
   - Start with PM2 or similar

---

## Generic Panel Deployment

For control panels not specifically covered:

### Step 1: Requirements Check

1. **Verify Support**
   - Node.js support (version 18+ required)
   - Database access (PostgreSQL preferred)
   - Custom web server configuration ability
   - SSL certificate support

### Step 2: Basic Setup

1. **File Upload**
   - Upload built application files
   - Set proper permissions

2. **Database Setup**
   - Create database and user
   - Note connection details

3. **Environment Configuration**
   - Set NODE_ENV=production
   - Configure DATABASE_URL
   - Set PORT (usually 3000)

### Step 3: Web Server Integration

1. **Reverse Proxy Setup**
   Configure your web server to proxy requests to Node.js:

   **Apache:**
   ```apache
   ProxyPass / http://localhost:3000/
   ProxyPassReverse / http://localhost:3000/
   ```

   **Nginx:**
   ```nginx
   location / {
       proxy_pass http://localhost:3000;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
   }
   ```

---

## Common Issues and Solutions

### Issue 1: Node.js App Won't Start

**Symptoms:**
- Error 502 Bad Gateway
- Application status shows "stopped"

**Solutions:**
1. Check Node.js version compatibility
2. Verify environment variables
3. Check application logs
4. Ensure database connection

**Debug Commands:**
```bash
# Check if port is in use
netstat -tulpn | grep :3000

# Check application logs
tail -f /path/to/app/logs/error.log

# Test database connection
psql -h localhost -U username -d database_name
```

### Issue 2: Database Connection Issues

**Symptoms:**
- Database connection errors
- App starts but API calls fail

**Solutions:**
1. Verify database credentials
2. Check database server status
3. Test connection manually
4. Review firewall settings

### Issue 3: File Permission Problems

**Symptoms:**
- Cannot write to logs
- Static files not serving
- Module loading errors

**Solutions:**
```bash
# Set correct permissions
find /path/to/app -type f -exec chmod 644 {} \;
find /path/to/app -type d -exec chmod 755 {} \;

# For Node.js files specifically
chmod +x /path/to/app/dist/index.js
```

### Issue 4: SSL/HTTPS Issues

**Symptoms:**
- Mixed content warnings
- SSL certificate errors
- Redirect loops

**Solutions:**
1. Configure proper SSL certificates
2. Update application to handle HTTPS
3. Set up proper redirects
4. Configure security headers

---

## Performance Optimization

### Control Panel Specific

1. **Resource Limits**
   - Increase memory limits if possible
   - Configure proper CPU allocation
   - Set appropriate disk quotas

2. **Caching Configuration**
   - Enable web server caching
   - Configure static file serving
   - Set proper cache headers

3. **Monitoring Setup**
   - Enable resource monitoring
   - Set up log rotation
   - Configure alerts

### Application Level

1. **Node.js Optimization**
   ```bash
   # Use production mode
   NODE_ENV=production
   
   # Optimize for production
   npm install --production
   npm prune
   ```

2. **Database Optimization**
   - Configure connection pooling
   - Add database indexes
   - Optimize queries

---

## Backup and Maintenance

### Automated Backups

1. **Application Backup Script**
   ```bash
   #!/bin/bash
   DATE=$(date +%Y%m%d_%H%M%S)
   BACKUP_DIR="/path/to/backups"
   APP_DIR="/path/to/app"
   
   # Create backup directory
   mkdir -p $BACKUP_DIR
   
   # Backup application files
   tar -czf $BACKUP_DIR/app_$DATE.tar.gz $APP_DIR
   
   # Backup database
   pg_dump -h localhost -U username database_name > $BACKUP_DIR/db_$DATE.sql
   
   # Clean old backups (keep 7 days)
   find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
   find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
   ```

2. **Schedule via Cron**
   ```bash
   # Add to crontab
   0 2 * * * /path/to/backup-script.sh
   ```

### Update Process

1. **Application Updates**
   ```bash
   # Stop application
   pm2 stop taskflow  # or control panel method
   
   # Backup current version
   cp -r /path/to/app /path/to/app-backup
   
   # Update files
   # ... upload new files ...
   
   # Install new dependencies
   npm install --production
   
   # Run migrations if needed
   npm run db:push
   
   # Start application
   pm2 start taskflow  # or control panel method
   ```

### Monitoring

1. **Health Checks**
   - Set up monitoring URLs
   - Configure uptime monitoring
   - Monitor resource usage

2. **Log Management**
   - Configure log rotation
   - Set up log monitoring
   - Archive old logs

For panel-specific issues, consult your hosting provider's documentation or support team.