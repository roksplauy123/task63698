# TaskFlow - Modern Task Management Application

A dynamic and responsive web-based TODO task application with PostgreSQL database integration for persistent task storage and management.

![TaskFlow](https://img.shields.io/badge/TaskFlow-v1.0-blue.svg)
![Node.js](https://img.shields.io/badge/Node.js-20.x-green.svg)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15+-blue.svg)
![React](https://img.shields.io/badge/React-18-blue.svg)

## Features

- ✅ **Task Management**: Add, edit, delete, and complete tasks with real-time updates
- 📱 **Responsive Design**: Seamless experience across desktop, tablet, and mobile devices
- 🗄️ **PostgreSQL Integration**: Reliable data persistence and management
- 🎨 **Modern UI**: Clean, Todoist-inspired interface with smooth animations
- ⚡ **Real-time Updates**: Instant task synchronization and status tracking
- 🔍 **Task Filtering**: View all, active, or completed tasks
- 📊 **Task Statistics**: Visual overview of task completion status
- 🚀 **High Performance**: Optimized for speed and reliability

## Quick Start

### Development

1. **Clone and Install**
   ```bash
   git clone https://github.com/your-username/taskflow.git
   cd taskflow
   npm install
   ```

2. **Setup Database**
   ```bash
   # Create PostgreSQL database
   createdb taskflow
   
   # Configure environment
   cp .env.example .env
   # Edit .env with your database credentials
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

   Open [http://localhost:5000](http://localhost:5000) to view the application.

### Production Deployment

Choose your preferred deployment method:

- **[Manual Installation](INSTALLATION.md)** - Complete server setup guide
- **[Nginx Deployment](DEPLOYMENT-NGINX.md)** - Detailed Nginx configuration  
- **[Control Panel Deployment](CONTROL-PANEL-DEPLOYMENT.md)** - cPanel, Plesk, DirectAdmin guides
- **[aaPanel Deployment](AAPANEL-DEPLOYMENT.md)** - Complete aaPanel hosting guide
- **[Environment Configuration](ENVIRONMENT-CONFIG.md)** - Complete configuration reference

## Tech Stack

### Frontend
- **React 18** - Modern UI library with hooks
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Radix UI** - Accessible component primitives
- **TanStack Query** - Server state management
- **Wouter** - Lightweight routing

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **TypeScript** - Type-safe server development
- **Drizzle ORM** - Type-safe database operations
- **Zod** - Runtime validation

### Database
- **PostgreSQL** - Reliable relational database
- **Drizzle Kit** - Database migrations and management

### DevOps
- **Vite** - Fast build tool and dev server
- **PM2** - Process management
- **Nginx** - Reverse proxy and web server
- **Docker** - Containerization support

## Project Structure

```
taskflow/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/           # Utility libraries
│   │   └── pages/         # Application pages
├── server/                 # Backend Express application
│   ├── db.ts              # Database connection
│   ├── routes.ts          # API routes
│   └── storage.ts         # Data access layer
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Database schema and types
├── docs/                   # Documentation files
├── dist/                   # Production build output
└── logs/                   # Application logs
```

## API Documentation

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tasks` | Retrieve all tasks |
| GET | `/api/tasks/:id` | Retrieve single task |
| POST | `/api/tasks` | Create new task |
| PATCH | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |

### Task Object

```typescript
interface Task {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

## Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `NODE_ENV` | Environment mode | Yes | - |
| `DATABASE_URL` | PostgreSQL connection string | Yes | - |
| `PORT` | Application port | No | 3000 |
| `LOG_LEVEL` | Logging level | No | info |

See [Environment Configuration](ENVIRONMENT-CONFIG.md) for complete details.

## Deployment Options

### 1. Replit Deployment (Recommended)
- One-click deployment
- Automatic scaling
- Built-in database
- SSL certificates included

### 2. Manual Server Deployment
- Full control over infrastructure
- Custom domain support
- Advanced configuration options
- See [Installation Guide](INSTALLATION.md)

### 3. Control Panel Deployment
- cPanel, Plesk, DirectAdmin support
- Simplified management interface
- Shared hosting compatible
- See [Control Panel Guide](CONTROL-PANEL-DEPLOYMENT.md)

### 4. Docker Deployment
- Containerized deployment
- Easy scaling and management
- Production-ready configuration
- See [Installation Guide](INSTALLATION.md#docker-installation)

## Performance

### Benchmarks
- **Response Time**: < 100ms average API response
- **Database**: Optimized queries with proper indexing
- **Frontend**: Lazy loading and code splitting
- **Caching**: Strategic caching for better performance

### Optimization Features
- Gzip compression
- Static file caching
- Database connection pooling
- Image optimization
- Bundle size optimization

## Security

- **HTTPS Enforcement**: SSL/TLS encryption
- **Input Validation**: Zod schema validation
- **Rate Limiting**: API request throttling
- **Security Headers**: CSP, HSTS, and more
- **Database Security**: Parameterized queries
- **Environment Variables**: Secure configuration management

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow TypeScript best practices
- Use meaningful commit messages
- Add tests for new features
- Update documentation as needed
- Ensure code passes linting

## Scripts

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build

# Database
npm run db:push      # Push schema changes
npm run db:studio    # Open database studio

# Code Quality
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript checks

# Production
npm start            # Start production server
```

## Monitoring and Maintenance

### Health Checks
- Application health endpoint: `/health`
- Database connectivity monitoring
- Performance metrics tracking

### Logging
- Structured JSON logging
- Error tracking and alerting
- Performance monitoring
- Access log analysis

### Backup Strategy
- Automated database backups
- Application file backups
- Configurable retention policies
- Recovery procedures documented

## Troubleshooting

### Common Issues

1. **Database Connection Issues**
   - Verify DATABASE_URL format
   - Check PostgreSQL service status
   - Confirm user permissions

2. **Build Failures**
   - Clear node_modules and reinstall
   - Check Node.js version compatibility
   - Verify environment variables

3. **Performance Issues**
   - Monitor database query performance
   - Check server resource usage
   - Review application logs

See detailed troubleshooting in [Installation Guide](INSTALLATION.md#troubleshooting).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- 📖 [Documentation](docs/)
- 🐛 [Issue Tracker](https://github.com/your-username/taskflow/issues)
- 💬 [Discussions](https://github.com/your-username/taskflow/discussions)
- 📧 [Email Support](mailto:support@taskflow.com)

## Acknowledgments

- Inspired by Todoist and Any.do for design excellence
- Built with modern web technologies and best practices
- Community feedback and contributions

---

**TaskFlow** - Making task management simple, beautiful, and efficient.

For detailed installation and deployment instructions, see our comprehensive documentation:
- [Installation Guide](INSTALLATION.md)
- [Nginx Deployment](DEPLOYMENT-NGINX.md)
- [Control Panel Deployment](CONTROL-PANEL-DEPLOYMENT.md)
- [aaPanel Deployment](AAPANEL-DEPLOYMENT.md)
- [Environment Configuration](ENVIRONMENT-CONFIG.md)